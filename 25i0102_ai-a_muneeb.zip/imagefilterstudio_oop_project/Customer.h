#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "User.h"

class customer : public user
{
private:
  string full_name;
  string gender;
  string phone;
  string city;
  int is_blocked; //0 or 1

public:
  customer(string cnic = "", string password = "", string name = "",
           string gender = "", string phone = "", string city = "",
           int blocked = 0)
      : user(cnic, password), full_name(name), gender(gender), phone(phone),
        city(city), is_blocked(blocked)
  {
  }

  virtual string get_role() const override 
  {
     return "Customer"; 
  }

  // Getters
  string get_full_name() const
   {
     return full_name; }
  string get_gender() const 
  {
     return gender; 
    }
  string get_phone() const 
  {
     return phone;
     }
  string get_city() const 
  {
     return city;
     }
  int get_is_blocked() const 
  { 
    return is_blocked;
   }

  // Setters
  void set_full_name(string name)
   { 
    full_name = name; 
  }
  void set_gender(string g) 
  { 
    gender = g; 
  }
  void set_phone(string p) 
  { phone = p; 
  }
  void set_city(string c) { 
    city = c; 
  }
  void set_is_blocked(int b) 
  {
     is_blocked = b; 
    }
};

#endif
