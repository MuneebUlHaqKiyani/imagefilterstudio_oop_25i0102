#ifndef FILTER_SESSION_H
#define FILTER_SESSION_H

#include "Filter.h"
#include "Image.h"

using namespace std;

class filter_session
{
private:
  filter **filters;
  int filter_count;
  int capacity;

public:
  filter_session();
  ~filter_session();

  //method chaining
  filter_session &add_filter(filter *f);

  //applying filters sequentially
  void apply_filters(image &img);

  //reset filters
  void clear_filters();
};

#endif
