#ifndef PIXEL_H
#define PIXEL_H

#include <iostream>
using namespace std;


class pixel
{
  
int channel_r;
  int channel_g;
  int channel_b;

public:
 
  pixel(int red = 0, int green = 0, int blue = 0);

  int get_r();
  int get_g();
  int get_b();

  void set_r(int red);
  void set_g(int green);
  void set_b(int blue);

  //0-255 cap
  static int clamp_value(int val);

  pixel operator+(pixel other_pixel);

  //<< for outut
  friend ostream &operator<<(ostream &out_stream, pixel &p);
};

#endif