#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

#include "Customer.h"
#include <string>

using namespace std;

class file_manager
{
public:
  //customers.txt
  bool add_customer(const customer &c);
  bool block_customer(string target_cnic);
  bool delete_customer(string target_cnic);
  bool authenticate_customer(string cnic, string password, customer &out_cust);
  bool is_cnic_registered(string cnic);
  void display_customers();

  //blocked_cnics.txt
  bool is_cnic_blocked(string cnic);
  bool block_cnic(string cnic);

  //catalog.txt
  void display_catalog();
  void display_enabled_filters();
  bool toggle_filter(string filter_id);
  bool is_filter_valid_and_enabled(string filter_id, string &out_name);

  //sessions.txt
  bool record_session(string cnic, string timestamp, string filters_applied, string output_file);
  void display_all_sessions();
  void display_customer_sessions(string cnic);
};

#endif
