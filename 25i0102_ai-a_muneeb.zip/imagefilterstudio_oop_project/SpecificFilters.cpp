#include "SpecificFilters.h"

//grayscale
grayscale_filter::grayscale_filter() : filter("Grayscale") {}

void grayscale_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    
    for (int i = 0; i < h; i++) 
    {
        for (int j = 0; j < w; j++) 
        {
            //we use at func to get the pixel
            pixel& p = img.at(i, j);
            
            //average
            int avg = (p.get_r() + p.get_g() + p.get_b()) / 3;
            p.set_r(avg);
            p.set_g(avg);
            p.set_b(avg);
        }
    }
}

//invert pixels 
invert_filter::invert_filter() : filter("Invert") 
{}

void invert_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            pixel& p = img.at(i, j);
        
        
            p.set_r(255 - p.get_r());
            p.set_g(255 - p.get_g());
            p.set_b(255 - p.get_b());
        }
    }
}

//add brightness
brightness_adjust_filter::brightness_adjust_filter(int amt) : filter("Brightness Adjust"), amount(amt) {}

void brightness_adjust_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    
    for (int i = 0; i < h; i++)
     {
        for (int j = 0; j < w; j++) 
        {
            pixel& p = img.at(i, j);
            
           
            p.set_r(p.get_r() + amount);
            p.set_g(p.get_g() + amount);
            p.set_b(p.get_b() + amount);
        }
    }
}

//contrast stretch
contrast_stretch_filter::contrast_stretch_filter() : filter("Contrast Stretch") {}

void contrast_stretch_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    
    int min_r = 255, max_r = 0;
    int min_g = 255, max_g = 0;
    int min_b = 255, max_b = 0;
    
    //absolute minimums and maximums
    for (int i = 0; i < h; i++) 
    {
        for (int j = 0; j < w; j++) 
        {
            pixel& p = img.at(i, j);
            
            if (p.get_r() < min_r) 
            min_r = p.get_r();
            
            if (p.get_r() > max_r)
             max_r = p.get_r();
            
            if (p.get_g() < min_g)
             min_g = p.get_g();
            
             if (p.get_g() > max_g)
             max_g = p.get_g();
            
            if (p.get_b() < min_b)
             min_b = p.get_b();
            
             if (p.get_b() > max_b)
             max_b = p.get_b();
        }
    }
    
    for (int i = 0; i < h; i++) 
    {
        for (int j = 0; j < w; j++) 
        {
            pixel& p = img.at(i, j);
            
            //new =(val-min) /(max - min)*255

            int new_r = (max_r == min_r) ? p.get_r() : (p.get_r() - min_r) * 255 / (max_r - min_r);
            int new_g = (max_g == min_g) ? p.get_g() : (p.get_g() - min_g) * 255 / (max_g - min_g);
            int new_b = (max_b == min_b) ? p.get_b() : (p.get_b() - min_b) * 255 / (max_b - min_b);
            
            p.set_r(new_r);
            p.set_g(new_g);
            p.set_b(new_b);
        }
    }
}

//only red channel
red_channel_only_filter::red_channel_only_filter() : filter("Red Channel Only") {}

void red_channel_only_filter::apply(image& img) 
{


    int w = img.get_width();
    int h = img.get_height();
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            pixel& p = img.at(i, j);
            p.set_g(0);
            p.set_b(0);
        }
    }
}

//only green channel
green_channel_only_filter::green_channel_only_filter() : filter("Green Channel Only") {}

void green_channel_only_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    for (int i = 0; i < h; i++) 
    {
        for (int j = 0; j < w; j++) 
        {
            pixel& p = img.at(i, j);
            p.set_r(0); 
            p.set_b(0); 
        }
  

  }
}

//only blue channel
blue_channel_only_filter::blue_channel_only_filter() : filter("Blue Channel Only") {}

void blue_channel_only_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    for (int i = 0; i < h; i++)
     {
        for (int j = 0; j < w; j++) 
        {
            pixel& p = img.at(i, j);
            p.set_r(0); 
            p.set_g(0); 
        }
    }
}

//horizontal flip
flip_horizontal_filter::flip_horizontal_filter() : filter("Flip Horizontal") 
{}

void flip_horizontal_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    
    //stop halfway across horizontal bounds
    for (int i = 0; i < h; i++) 
    {
        for (int j = 0; j < w / 2; j++) 
        {
            pixel temp = img.at(i, j);
            img.at(i, j) = img.at(i, w - 1 - j);
            img.at(i, w - 1 - j) = temp;
        }
    }
}

//vertical flip
flip_vertical_filter::flip_vertical_filter() : filter("Flip Vertical") 
{}

void flip_vertical_filter::apply(image& img) 
{
    int w = img.get_width();
    int h = img.get_height();
    
    //stop halfway down vertical bounds
    for (int i = 0; i < h / 2; i++) 
    {
        for (int j = 0; j < w; j++) 
        {
            pixel temp = img.at(i, j);
            img.at(i, j) = img.at(h - 1 - i, j);
            img.at(h - 1 - i, j) = temp;
        }
    }
}

//box blur
box_blur_filter::box_blur_filter() : filter("Box Blur (3x3)") 
{}

void box_blur_filter::apply(image& img)
 {
    int w = img.get_width();
    int h = img.get_height();
    
    
    image copy_img(img);
    
    for (int i = 0; i < h; i++) 
    {
        for (int j = 0; j < w; j++) 
        {
            int sum_r = 0, sum_g = 0, sum_b = 0;
            int count = 0;
            
            //Loop 3x3
            for (int r = i - 1; r <= i + 1; r++) 
            {
                for (int c = j - 1; c <= j + 1; c++) 
                {
                    if (r >= 0 && r < h && c >= 0 && c < w) 
                    {
                        pixel& neighbor = copy_img.at(r, c);
                        sum_r += neighbor.get_r();
                        sum_g += neighbor.get_g();
                        sum_b += neighbor.get_b();
                        count++;
                    }
                }
            }
            
            pixel& p = img.at(i, j);
            p.set_r(sum_r / count);
            p.set_g(sum_g / count);
            p.set_b(sum_b / count);
        }
    }
}
