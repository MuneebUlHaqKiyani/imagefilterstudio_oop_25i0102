#ifndef USER_H
#define USER_H

#include <string>

using namespace std;

class user 
{
protected:
    string cnic;
    string password;

public:
    user(string user_cnic = "", string user_password = "") : cnic(user_cnic), password(user_password) 
    {}
    virtual ~user() 
    {}

    //different roles for admins and users so polymorphism is used
    virtual string get_role() const = 0;

    string get_cnic() const 
    { 
        return cnic; 
    }
    string get_password() const 
    { 
        return password; 
    }
    
    void set_cnic(string new_cnic) 
    { 
        cnic = new_cnic; 
    }
    void set_password(string new_password) 
    {
         password = new_password; 
        }
};

#endif
