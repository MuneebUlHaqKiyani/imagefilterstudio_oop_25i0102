#include "FileManager.h"
#include <iostream>
#include <fstream>
#include <cstdio>

using namespace std;

//return tokens number used in almost all functions in this file
int split_string_fixed(const string& str, char delimiter, string parts[], int max_parts)
 {
    int count = 0;
    string current_token = "";
    for (int i = 0; i < str.length(); i++) 
    {
        if (str[i] == delimiter)
         {
            if (count < max_parts) parts[count++] = current_token;
            current_token = "";
        } else {
            current_token += str[i];
        }
    }
    if (count < max_parts) parts[count++] = current_token;
    return count;
}

bool file_manager::add_customer(const customer& c) 
{
    ofstream file("customers.txt", ios::app);
    if (!file.is_open()) 
    return false;
    
    file << c.get_cnic() << "|" 
         << c.get_password() << "|" 
         << c.get_full_name() << "|" 
         << c.get_gender() << "|" 
         << c.get_phone() << "|" 
         << c.get_city() << "|" 
         << c.get_is_blocked() << "\n";
    
    file.close();
    return true;
}

bool file_manager::block_customer(string target_cnic)
 {
    ifstream infile("customers.txt");
    ofstream outfile("temp.txt");
    if (!infile.is_open() || !outfile.is_open()) 
    return false;
    
    bool found = false;
    string line;
    while (getline(infile, line))
     {
        if (line.empty())
         continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        
        if (count >= 7 && parts[0] == target_cnic) 
        {
            parts[6] = "1"; //Set blocked to 1
            found = true;
            outfile << parts[0] << "|" << parts[1] << "|" << parts[2] << "|"
                    << parts[3] << "|" << parts[4] << "|" << parts[5] << "|"
                    << parts[6] << "\n";
        } else {
            outfile << line << "\n";
        }
    }
    infile.close();
    outfile.close();
    
    remove("customers.txt");
    rename("temp.txt", "customers.txt");
    
    if (found) {
        block_cnic(target_cnic);
    }
    return found;
}

bool file_manager::delete_customer(string target_cnic) 
{
    ifstream infile("customers.txt");
    ofstream outfile("temp.txt");
    if (!infile.is_open() || !outfile.is_open())
     return false;
    
    bool found = false;
    string line;
    while (getline(infile, line)) 
    {
        if (line.empty()) 
        continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        
        if (count >= 7 && parts[0] == target_cnic) 
        {
            found = true; //skip writing this line to temp
        } else {
            outfile << line << "\n";
        }
    }
    infile.close();
    outfile.close();
    
    remove("customers.txt");
    rename("temp.txt", "customers.txt");
    
    return found;
}

bool file_manager::authenticate_customer(string cnic, string password, customer& out_cust) {
    ifstream file("customers.txt");
    if (!file.is_open())
     return false;
    
    string line;
    while (getline(file, line)) 
    {
        if (line.empty())
         continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        
        if (count >= 7 && parts[0] == cnic && parts[1] == password) 
        {
            out_cust = customer(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6] == "1" ? 1 : 0);
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

bool file_manager::is_cnic_registered(string cnic) 
{
    ifstream file("customers.txt");
    if (!file.is_open())
     return false;
    
    string line;
    while (getline(file, line)) 
    {
        if (line.empty()) 
        continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        
        if (count > 0 && parts[0] == cnic) 
        {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

void file_manager::display_customers() 
{
    ifstream file("customers.txt");
    if (!file.is_open()) 
    {
        cout << "No customers found.\n";
        return;
    }
    
    string line;
    while (getline(file, line)) 
    {
        if (line.empty()) 
        continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        if (count >= 7) 
        {
            cout << parts[0] << " | " << parts[2] << " | Blocked: " << parts[6] << "\n";
        }
    }
    file.close();
}

bool file_manager::is_cnic_blocked(string cnic) 
{
    ifstream file("blocked_cnics.txt");
    if (!file.is_open()) 
    return false;
    
    string line;
    while (getline(file, line))
     {
        if (line == cnic) 
        {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

bool file_manager::block_cnic(string cnic) 
{
    if (is_cnic_blocked(cnic)) 
    return true;
    ofstream file("blocked_cnics.txt", ios::app);
    if (!file.is_open()) 
    return false;
    file << cnic << "\n";
    file.close();
    return true;
}

void file_manager::display_catalog() 
{
    ifstream file("catalog.txt");
    if (!file.is_open()) {
        cout << "Catalog is empty.\n";
        return;
    }
    string line;
    while (getline(file, line))
     {
        if (line.empty()) 
        continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        if (count >= 4 && parts[0] != "FilterID") {
            cout << parts[0] << " | " << parts[1] << " [" << (parts[3] == "1" ? "ENABLED" : "DISABLED") << "]\n";
        }
    }
    file.close();
}

void file_manager::display_enabled_filters() 
{
    ifstream file("catalog.txt");
    if (!file.is_open()) 
    return;
    string line;
    while (getline(file, line)) 
    {
        if (line.empty()) 
        continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        if (count >= 4 && parts[0] != "FilterID" && parts[3] == "1")
         {
            cout << parts[0] << " : " << parts[1] << " [" << parts[2] << "]\n";
        }
    }
    file.close();
}

bool file_manager::toggle_filter(string filter_id) 
{
    ifstream infile("catalog.txt");
    ofstream outfile("temp.txt");
    if (!infile.is_open() || !outfile.is_open()) 
    return false;
    
    bool found = false;
    string line;
    while (getline(infile, line))
     {
        if (line.empty())
         continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        
        if (count >= 4 && parts[0] == "FilterID") 
        {
            outfile << line << "\n";
        } else if (count >= 4 && parts[0] == filter_id)
         {
            found = true;
            parts[3] = (parts[3] == "1") ? "0" : "1";
            outfile << parts[0] << "|" << parts[1] << "|" << parts[2] << "|" << parts[3] << "\n";
        } else {
            outfile << line << "\n";
        }
    }
    infile.close();
    outfile.close();
    remove("catalog.txt");
    rename("temp.txt", "catalog.txt");
    return found;
}

bool file_manager::is_filter_valid_and_enabled(string filter_id, string& out_name)
 {
    ifstream file("catalog.txt");
    if (!file.is_open()) 
    return false;
    string line;
    while (getline(file, line)) 
    {
        if (line.empty()) 
        continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        if (count >= 4 && parts[0] == filter_id && parts[3] == "1")
         {
            out_name = parts[1];
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

bool file_manager::record_session(string cnic, string timestamp, string filters_applied, string output_file) 
{
    ofstream file("sessions.txt", ios::app);
    if (!file.is_open()) return false;
    file << cnic << "|" << timestamp << "|" << filters_applied << "|" << output_file << "\n";
    file.close();
    return true;
}

void file_manager::display_all_sessions() 
{
    ifstream file("sessions.txt");
    if (!file.is_open()) {
        cout << "No sessions recorded yet.\n";
        return;
    }
    string line;
    while (getline(file, line)) 
    {
        if (line.empty()) 
        continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        if (count >= 4) {
            cout << "CNIC: " << parts[0] << " | Time: " << parts[1] 
                 << " | Filters: " << parts[2] << " | File: " << parts[3] << "\n";
        }
    }
    file.close();
}

void file_manager::display_customer_sessions(string cnic)
 {
    ifstream file("sessions.txt");
    if (!file.is_open()) {
        cout << "No sessions recorded yet.\n";
        return;
    }
    string line;
    bool found = false;
    while (getline(file, line)) 
    {
        if (line.empty())
         continue;
        string parts[10];
        int count = split_string_fixed(line, '|', parts, 10);
        if (count >= 4 && parts[0] == cnic) {
            cout << " Time: " << parts[1] << " | Filters: " << parts[2] << " | File: " << parts[3] << "\n";
            found = true;
        }
    }
    if (!found) cout << "No history found for this customer.\n";
    file.close();
}
