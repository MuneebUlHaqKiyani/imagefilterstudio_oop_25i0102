#ifndef ADMIN_H
#define ADMIN_H

#include "User.h"

class admin : public user
{
public:
  //hardcoding as there will only be 1 admin
  admin() : user("admin", "admin123") 
  {}

  virtual string get_role() const override 
  { 
    return "Admin";
   }

  bool authenticate(string entered_username, string entered_password) const
  {
    return (entered_username == cnic && entered_password == password);
  }
};

#endif
