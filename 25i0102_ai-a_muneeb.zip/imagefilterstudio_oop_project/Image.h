#ifndef IMAGE_H
#define IMAGE_H

#include "Interfaces.h"
#include "Pixel.h"
#include <string>

using namespace std;
//need for friend
class filter_session;


//multiple inheritance
class image : public saveable_object, public displayable_object
{
private:
  //double pointer for pixel array
  pixel **pixels;
  int width;
  int height;

public:
 
  image();

  image(int w, int h);

  //for image loading
  image(string file_path);

  //copy constructor usin it for deep copy
  image(const image &src);


  virtual ~image();

  int get_width() const;
  int get_height() const;

  //at func returns a specific pixel
  pixel &at(int row, int col);
  const pixel &at(int row, int col) const;


  void save_to_file(string file_name) override;

  void display_ascii() override;

  //friend class but idk why we did tht but was asked in pdf 
  friend class filter_session;
};

#endif
