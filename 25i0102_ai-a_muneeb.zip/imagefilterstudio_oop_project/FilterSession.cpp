#include "FilterSession.h"
#include <iostream>

using namespace std;

filter_session::filter_session()
{
  capacity = 10;
  filter_count = 0;
  filters = new filter *[capacity];
}

filter_session::~filter_session()
{
  delete[] filters;
}

filter_session &filter_session::add_filter(filter *f)
{
  if (f != nullptr)
  {
    if (filter_count >= capacity)
    {//double it
      capacity *= 2;
      filter **new_filters = new filter *[capacity];
      for (int i = 0; i < filter_count; i++)
      {
        new_filters[i] = filters[i];
      }
      delete[] filters;
      filters = new_filters;
    }
    filters[filter_count++] = f;
  }
  //for method chaining
  return *this;
}

void filter_session::apply_filters(image &img)
{
  for (int i = 0; i < filter_count; i++)
  {
    cout << "Applying filter " << i + 1 << "           " << filter_count << ": "
         << filters[i]->get_name() << " ...\n";

    filters[i]->apply(img);

    //print after each filter
    img.display_ascii();
  }
  cout << "All " << filter_count << " filters applied.\n";
}

void filter_session::clear_filters() { filter_count = 0; }
