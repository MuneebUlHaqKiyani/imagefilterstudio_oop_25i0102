#ifndef INTERFACES_H
#define INTERFACES_H

#include <string>
using namespace std;


class saveable_object
{
public:
  
  virtual void save_to_file(string file_name) = 0;
};


class displayable_object
{
public:
 
  virtual void display_ascii() = 0;
};

#endif