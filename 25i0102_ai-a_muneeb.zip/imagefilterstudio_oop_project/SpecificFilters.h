#ifndef SPECIFIC_FILTERS_H
#define SPECIFIC_FILTERS_H

#include "Filter.h"

//grayscale  average of pixels
class grayscale_filter : public filter 
{
public:
    grayscale_filter();
    virtual void apply(image& img) override;
};

//invert pixels 255-r,255-g,255-b
class invert_filter : public filter 
{
public:
    invert_filter();
    virtual void apply(image& img) override;
};

//add brightness
class brightness_adjust_filter : public filter 
{
private:
    int amount; 
public:
    brightness_adjust_filter(int amt);
    virtual void apply(image& img) override;
};

//contrast stretch
class contrast_stretch_filter : public filter 
{
public:
    contrast_stretch_filter();
    virtual void apply(image& img) override;
};

//only red channel
class red_channel_only_filter : public filter 
{
public:
    red_channel_only_filter();
    virtual void apply(image& img) override;
};

//only green channel
class green_channel_only_filter : public filter 
{
public:
    green_channel_only_filter();
    virtual void apply(image& img) override;
};

//only blue channel
class blue_channel_only_filter : public filter 
{
public:
    blue_channel_only_filter();
    virtual void apply(image& img) override;
};

//horizontal flip mirroring left to right
class flip_horizontal_filter : public filter 
{
public:
    flip_horizontal_filter();
    virtual void apply(image& img) override;
};

//vertical flip mirroring top to bottom
class flip_vertical_filter : public filter 
{
public:
    flip_vertical_filter();
    virtual void apply(image& img) override;
};

//box blur
class box_blur_filter : public filter 
{
public:
    box_blur_filter();
    virtual void apply(image& img) override;
};

#endif
