#include "Image.h"
#include <iostream>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

using namespace std;

//default constructor zeroes variables
image::image() : pixels(nullptr), width(0), height(0)
 {}

//blank pixel
image::image(int w, int h) : width(w), height(h)
{
  pixels = new pixel *[height];
  for (int i = 0; i < height; ++i)
  {

    pixels[i] = new pixel[width];
  }
}


image::image(string file_path)
{
  int channels;
  //stbi_load
  unsigned char *data =stbi_load(file_path.c_str(), &width, &height, &channels, 3);

  if (data == nullptr)
  {
    cout << "Error: Could not load image from "<< file_path << endl;
    pixels = nullptr;
    width = 0;
    height = 0;
    return;
  }

  pixels = new pixel *[height];
  for (int i = 0; i < height; ++i)
  {
    pixels[i] = new pixel[width];
    for (int j = 0; j < width; ++j)
    {
      
      int index = 3 * (i * width + j);
      pixels[i][j] = pixel(data[index], data[index + 1], data[index + 2]);
    }
  }

  //delete data flat array
  stbi_image_free(data);
}
//need deep copy for some filters
image::image(const image &src) : width(src.width), height(src.height)
{
  if (src.pixels == nullptr)
  {
    pixels = nullptr;
    return;
  }

  pixels = new pixel *[height];
  for (int i = 0; i < height; ++i)
  {
    pixels[i] = new pixel[width];
    for (int j = 0; j < width; ++j)
    {
      //deep copy
      pixels[i][j] = src.pixels[i][j];
    }
  }
}


image::~image()
{
  if (pixels != nullptr)
  {
    for (int i = 0; i < height; ++i)
    {
      delete[] pixels[i];
    }
    delete[] pixels;
  }
}

int image::get_width() const 
{ return width; }

int image::get_height() const 
{ return height; }

//at for pixels in image
pixel &image::at(int row, int col) 
{ return pixels[row][col]; }
const pixel &image::at(int row, int col) const 
{ return pixels[row][col]; }

//going back to flat to give the output
void image::save_to_file(string file_name)
{
  if (pixels == nullptr || width == 0 || height == 0)
  {
    cout << "Errorrrrrrr No image data to save!" << endl;
    return;
  }

  unsigned char *data = new unsigned char[width * height * 3];
  for (int i = 0; i < height; ++i)
  {
    for (int j = 0; j < width; ++j)
    {
      int index = 3 * (i * width + j);
      data[index] = pixels[i][j].get_r();
      data[index + 1] = pixels[i][j].get_g();
      data[index + 2] = pixels[i][j].get_b();
    }
  }

  //c_str for converting to c string
  stbi_write_png(file_name.c_str(), width, height, 3, data, width * 3);

  //delete 1d
  delete[] data;
}
//terminal output
void image::display_ascii()
{
  if (pixels == nullptr || width == 0 || height == 0)
  {
    cout << "No image to display." << endl;
    return;
  }

  cout << "Image preview ("<< width << " x " << height << ")" << endl;

//downscaling
  int step_r = height > 20 ? height / 20 : 1;
  int step_c = width > 40 ? width / 40 : 1;

  for (int i = 0; i < height; i += step_r)
  {
    for (int j = 0; j < width; j += step_c)
    {
      cout << pixels[i][j];
    }
    cout << endl;
  }

  cout << "Image size : " << width << " x " << height
       << "  Total pixels: " << (width * height) << endl;
}
