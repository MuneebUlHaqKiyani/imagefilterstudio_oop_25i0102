#include "Pixel.h"

//clamping during making
pixel::pixel(int red, int green, int blue)
{
  channel_r = clamp_value(red);
  channel_g = clamp_value(green);
  channel_b = clamp_value(blue);
}

int pixel::get_r() 
{ 
  return channel_r;
 }
int pixel::get_g() 
{
   return channel_g; 
  }
int pixel::get_b() 
{
   return channel_b; 
  }


void pixel::set_r(int red) 
{
   channel_r = clamp_value(red); 
  }
void pixel::set_g(int green) 
{
   channel_g = clamp_value(green); 
  }
void pixel::set_b(int blue) 
{
   channel_b = clamp_value(blue); 
  }


int pixel::clamp_value(int val)
{
  if (val < 0)
  {
    return 0; 
  }
  if (val > 255)
  {
    return 255;
  }
  return val;
}


pixel pixel::operator+(pixel other_pixel)
{
  pixel temp_result;

  
  temp_result.set_r(this->channel_r + other_pixel.channel_r);
  temp_result.set_g(this->channel_g + other_pixel.channel_g);
  temp_result.set_b(this->channel_b + other_pixel.channel_b);

  return temp_result;
}


ostream &operator<<(ostream &out_stream, pixel &p)
{
  // get average brightness across all three current channels
  int avg_brightness = (p.channel_r + p.channel_g + p.channel_b) / 3;

  // figure out which ascii character to show based on the project requirements
  char print_char = ' ';

  if (avg_brightness < 30)
  {
    print_char = ' ';
  }
  else if (avg_brightness < 60)
  {
    print_char = '.';
  }
  else if (avg_brightness < 90)
  {
    print_char = ':';
  }
  else if (avg_brightness < 120)
  {
    print_char = '-';
  }
  else if (avg_brightness < 150)
  {
    print_char = '=';
  }
  else if (avg_brightness < 180)
  {
    print_char = '+';
  }
  else if (avg_brightness < 210)
  {
    print_char = '*';
  }
  else if (avg_brightness < 240)
  {
    print_char = '#';
  }
  else
  {
    print_char = '@';
  }
//output
  out_stream << print_char;

  return out_stream;
}