#include "Admin.h"
#include "Customer.h"
#include "FileManager.h"
#include "FilterSession.h"
#include "Image.h"
#include "SpecificFilters.h"
#include <iostream>
#include <string>

using namespace std;

void admin_panel(file_manager &fm);
void customer_panel(file_manager &fm, customer &current_customer);

void clear_screen()
{
#ifdef _WIN32
  system("cls");
#else
  system("clear");
#endif
}

int main()
{
  file_manager fm;
  bool running = true;

  while (running)
  {
    clear_screen();
    cout << "\nIMAGE FILTER STUDIO\n";
    cout << "1. Admin Login\n";
    cout << "2. Customer Login\n";
    cout << "3. New Customer? Register here\n";
    cout << "4. Exit\n";
    cout << "Your choice: ";

    int choice;
    cin >> choice;

    if (choice == 1)
    {
      string username, password;
      cout << "\n\n               Admin Login  \n";
      cout << "Username: ";
      cin >> username;
      cout << "Password: ";
      cin >> password;

      admin a;
      if (a.authenticate(username, password))
      {
        cout << "Login successful.\n";
        admin_panel(fm);
      }
      else
      {
        cout << "Invalid credentials. Press enter to continue.\n";
        cin.ignore(10000, '\n');
        cin.get();
      }
    }
    else if (choice == 2)
    {
      string cnic, password;
      cout << "\n          Customer Login\n";
      cout << "CNIC: ";
      cin >> cnic;
      cout << "Password: ";
      cin >> password;

      if (fm.is_cnic_blocked(cnic))
      {
        cout << "Your account has been blocked by the admin. Press enter.\n";
        cin.ignore(10000, '\n');
        cin.get();
        continue;
      }

      customer current_user;
      if (fm.authenticate_customer(cnic, password, current_user))
      {
        if (current_user.get_is_blocked() == 1)
        {
          cout << "Your account has been blocked by the admin. Press enter.\n";
        }
        else
        {
          cout << "Login successful. Press enter.\n";
          cin.ignore(10000, '\n');
          cin.get();
          customer_panel(fm, current_user);
          continue;
        }
      }
      else
      {
        cout << "Invalid CNIC or password. Press enter.\n";
      }
      cin.ignore(10000, '\n');
      cin.get();
    }
    else if (choice == 3)
    {
      string cnic, pass, name, gender, phone, city;
      cout << "\n                Registration  \n";
      cout << "Enter 13-digit CNIC: ";
      cin >> cnic;
      if (cnic.length() != 13)
      {
        cout << "Invalid CNIC length. Must be 13 digits. Press enter.\n";
        cin.ignore(10000, '\n');
        cin.get();
        continue;
      }
      if (fm.is_cnic_blocked(cnic))
      {
        cout << "This CNIC is blocked. Press enter.\n";
        cin.ignore(10000, '\n');
        cin.get();
        continue;
      }
      if (fm.is_cnic_registered(cnic))
      {
        cout << "CNIC already registered. Press enter.\n";
        cin.ignore(10000, '\n');
        cin.get();
        continue;
      }
      cout << "Enter password: ";
      cin >> pass;
      cout << "Enter Full Name: ";
      cin.ignore();
      getline(cin, name);
      cout << "Enter Gender (M/F): ";
      cin >> gender;
      cout << "Enter Phone: ";
      cin >> phone;
      cout << "Enter City: ";
      cin.ignore();
      getline(cin, city);

      customer new_cust(cnic, pass, name, gender, phone, city, 0);
      fm.add_customer(new_cust);
      cout << "Registration successful! Press enter to return to main menu.\n";
      cin.get();
    }
    else if (choice == 4)
    {
      running = false;
    }
  }
  return 0;
}

void admin_panel(file_manager &fm)
{
  bool in_panel = true;
  while (in_panel)
  {
    clear_screen();
    cout << "          ADMIN PANEL : Image Filter Studio     \n";
    cout << "1. Manage Filter Catalog\n";
    cout << "2. Manage Customers\n";
    cout << "3. View All Sessions\n";
    cout << "4. Logout\n";
    cout << "Your choice: ";

    int choice;
    cin >> choice;

    if (choice == 1)
    {
      cout << "\n            Filter Catalog            \n";
      fm.display_catalog();
      cout << "Enter Filter ID to toggle (or 0 to go back): ";
      string id;
      cin >> id;
      if (id != "0")
      {
        if (fm.toggle_filter(id))
          cout << "Filter toggled.\n";
        else
          cout << "Filter ID not found.\n";
      }
      cout << "Press enter to continue.\n";
      cin.ignore(10000, '\n');
      cin.get();
    }
    else if (choice == 2)
    {
      cout << "\n              Customer List            \n";
      fm.display_customers();
      cout << "Enter CNIC to block (or 0 to go back): ";
      string cnic;
      cin >> cnic;
      if (cnic != "0")
      {
        if (fm.block_customer(cnic))
          cout << "Customer blocked.\n";
        else
          cout << "CNIC not found.\n";
      }
      cout << "Press enter to continue.\n";
      cin.ignore(10000, '\n');
      cin.get();
    }
    else if (choice == 3)
    {
      cout << "\n              All Sessions           \n";
      fm.display_all_sessions();
      cout << "Press enter to continue.\n";
      cin.ignore(10000, '\n');
      cin.get();
    }
    else if (choice == 4)
    {
      in_panel = false;
    }
  }
}

void customer_panel(file_manager &fm, customer &current_customer)
{
  bool in_panel = true;
  while (in_panel)
  {
    clear_screen();
    cout << "          Welcome, " << current_customer.get_full_name() << "     \n";
    cout << "1. Browse Filter Catalog\n";
    cout << "2. Apply Filters to an Image\n";
    cout << "3. View My Session History\n";
    cout << "4. Logout\n";
    cout << "Your choice: ";

    int choice;
    cin >> choice;

    if (choice == 1)
    {
      cout << "\n          Available Filters         \n";
      fm.display_enabled_filters();
      cout << "Press enter to continue.\n";
      cin.ignore(10000, '\n');
      cin.get();
    }
    else if (choice == 2)
    {
      cout << "Enter path to image (e.g. photo.jpg): ";
      string path;
      cin.ignore();
      getline(cin, path);

      image img(path);
      if (img.get_width() == 0 || img.get_height() == 0)
      {
        cout << "Failed to load image. Make sure the file exists and is a valid JPG/PNG.\n";
        cout << "Press enter to continue.\n";
        cin.get();
        continue;
      }

      cout << "Image loaded: " << img.get_width() << " x " << img.get_height()
           << " pixels.\n";
      img.display_ascii();

      filter_session session;
      string applied_filters_str = "";

      while (true)
      {
        cout << "\nAvailable Filters:\n";
        fm.display_enabled_filters();
        cout << "Enter filter ID to add (0 to finish): ";
        string f_id;
        cin >> f_id;

        if (f_id == "0")
          break;

        string filter_name;
        if (fm.is_filter_valid_and_enabled(f_id, filter_name))
        {
          filter *f = nullptr;
          if (f_id == "01")
            f = new grayscale_filter();
          else if (f_id == "02")
            f = new invert_filter();
          else if (f_id == "03")
          {
            cout << "Enter brightness amount (-100 to +100): ";
            int amt;
            cin >> amt;
            f = new brightness_adjust_filter(amt);
          }
          else if (f_id == "04")
            f = new contrast_stretch_filter();
          else if (f_id == "05")
            f = new red_channel_only_filter();
          else if (f_id == "06")
            f = new green_channel_only_filter();
          else if (f_id == "07")
            f = new blue_channel_only_filter();
          else if (f_id == "08")
            f = new box_blur_filter();
          else if (f_id == "09")
            f = new flip_horizontal_filter();
          else if (f_id == "10")
            f = new flip_vertical_filter();

          if (f != nullptr)
          {
            session.add_filter(f);
            if (applied_filters_str != "")
              applied_filters_str += ">";
            applied_filters_str += filter_name;
            cout << "Added: " << filter_name << "\n";
          }
        }
        else
        {
          cout << "Invalid or disabled filter ID.\n";
        }
      }

      cout << "\n           Applying Pipeline                 \n";
      session.apply_filters(img);

      cout << "Save result? (y/n): ";
      char save_choice;
      cin >> save_choice;
      if (save_choice == 'y' || save_choice == 'Y')
      {
        string out_path = current_customer.get_cnic() + "_output.png";
        img.save_to_file(out_path);
        cout << "Saving as PNG to: " << out_path << "\n";
        fm.record_session(current_customer.get_cnic(), "timestamp_now",
                          applied_filters_str, out_path);
        cout << "Session recorded.\n";
      }
      cout << "Press enter to continue.\n";
      cin.ignore(10000, '\n');
      cin.get();
    }
    else if (choice == 3)
    {
      cout << "\n           My Session History            \n";
      fm.display_customer_sessions(current_customer.get_cnic());
      cout << "Press enter to continue.\n";
      cin.ignore(10000, '\n');
      cin.get();
    }
    else if (choice == 4)
    {
      in_panel = false;
    }
  }
}
