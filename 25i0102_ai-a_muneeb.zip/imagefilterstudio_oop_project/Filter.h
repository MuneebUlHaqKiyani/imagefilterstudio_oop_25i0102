#ifndef FILTER_H
#define FILTER_H

#include "Image.h"
#include <string>

using namespace std;
//abtrach filter
class filter
{
protected:
  string filter_name;

public:
  filter(string name = "Generic Filter") : filter_name(name) {}

  virtual ~filter() {}

  virtual void apply(image &img) = 0;

  string get_name() const
   { return filter_name; }
};

#endif
